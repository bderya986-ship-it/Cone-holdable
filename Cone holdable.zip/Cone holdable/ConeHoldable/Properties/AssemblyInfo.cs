﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyCompany("ConeHoldable")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+21029ada2c1b31684db4a7c8d585f4455bb1f429")]
[assembly: AssemblyProduct("ConeHoldable")]
[assembly: AssemblyTitle("ConeHoldable")]

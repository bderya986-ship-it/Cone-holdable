﻿using System;
using System.Reflection;
using HarmonyLib;

namespace ConeHoldable
{
	// Token: 0x02000002 RID: 2
	public class HarmonyPatches
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06000002 RID: 2 RVA: 0x00002057 File Offset: 0x00000257
		public static bool IsPatched { get; private set; }

		// Token: 0x06000003 RID: 3 RVA: 0x00002060 File Offset: 0x00000260
		internal static void ApplyHarmonyPatches()
		{
			bool flag = !HarmonyPatches.IsPatched;
			if (flag)
			{
				bool flag2 = HarmonyPatches.instance == null;
				if (flag2)
				{
					HarmonyPatches.instance = new Harmony("com.goldentrophy.gorillatag.coneholdable");
				}
				HarmonyPatches.instance.PatchAll(Assembly.GetExecutingAssembly());
				HarmonyPatches.IsPatched = true;
			}
		}

		// Token: 0x06000004 RID: 4 RVA: 0x000020B0 File Offset: 0x000002B0
		internal static void RemoveHarmonyPatches()
		{
			bool flag = HarmonyPatches.instance != null && HarmonyPatches.IsPatched;
			if (flag)
			{
				HarmonyPatches.instance.UnpatchSelf();
				HarmonyPatches.IsPatched = false;
			}
		}

		// Token: 0x04000001 RID: 1
		private static Harmony instance;

		// Token: 0x04000003 RID: 3
		public const string InstanceId = "com.goldentrophy.gorillatag.coneholdable";
	}
}

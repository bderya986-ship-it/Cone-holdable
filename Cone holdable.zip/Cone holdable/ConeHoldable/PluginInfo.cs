﻿using System;

namespace ConeHoldable
{
	// Token: 0x02000004 RID: 4
	internal class PluginInfo
	{
		// Token: 0x04000005 RID: 5
		public const string GUID = "com.goldentrophy.gorillatag.coneholdable";

		// Token: 0x04000006 RID: 6
		public const string Name = "ConeHoldable";

		// Token: 0x04000007 RID: 7
		public const string Version = "1.0.5";
	}
}

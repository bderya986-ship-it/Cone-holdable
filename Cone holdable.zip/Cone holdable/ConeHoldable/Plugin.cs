﻿using System;
using System.IO;
using System.Reflection;
using BepInEx;
using UnityEngine;

namespace ConeHoldable
{
	// Token: 0x02000003 RID: 3
	[BepInPlugin("com.goldentrophy.gorillatag.coneholdable", "ConeHoldable", "1.0.5")]
	public class Plugin : BaseUnityPlugin
	{
		// Token: 0x06000006 RID: 6 RVA: 0x000020EE File Offset: 0x000002EE
		private void Awake()
		{
			GorillaTagger.OnPlayerSpawned(new Action(this.OnGameInitialized));
		}

		// Token: 0x06000007 RID: 7 RVA: 0x00002104 File Offset: 0x00000304
		private void OnGameInitialized()
		{
			GameObject gameObject = Plugin.LoadAsset("ConeHold");
			gameObject.transform.SetParent(GorillaTagger.Instance.offlineVRRig.transform.Find("rig/hand.R"), false);
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002144 File Offset: 0x00000344
		public static GameObject LoadAsset(string assetName)
		{
			bool flag = Plugin.assetBundle == null;
			if (flag)
			{
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ConeHoldable.Resources.conehold");
				Plugin.assetBundle = AssetBundle.LoadFromStream(manifestResourceStream);
				manifestResourceStream.Close();
			}
			return Object.Instantiate<GameObject>(Plugin.assetBundle.LoadAsset<GameObject>(assetName));
		}

		// Token: 0x0600000A RID: 10 RVA: 0x000021A8 File Offset: 0x000003A8
		public static void ApplyHarmonyPatches()
		{
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = executingAssembly.GetManifestResourceStream("Harmony.PatchInfo.bin");
			MemoryStream memoryStream = new MemoryStream();
			manifestResourceStream.CopyTo(memoryStream);
			byte[] array = memoryStream.ToArray();
			Assembly assembly = Assembly.Load(array);
			Type type = assembly.GetType("HarmonyX.Internal.PatchProcessor");
			MethodInfo method = type.GetMethod("Initialize");
			method.Invoke(null, null);
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00002209 File Offset: 0x00000409
		public void Start()
		{
			Plugin.ApplyHarmonyPatches();
		}

		// Token: 0x04000004 RID: 4
		private static AssetBundle assetBundle;
	}
}
